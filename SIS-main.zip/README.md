# SIS
Systemy i sieci światłowodowe - projekt

Zadanie - zaplanuj sieć o minimalnym rozmiarze łączącą punkty brzegowe (ONU) z punktami pośrednimi (splitter), połącz punkty pośrednie. MST z dwoma rodzajami punktów

1. Losowo z szumem
2. Losowo naiwnie
3. K-means
4. K-rand (kombo)


Rodzaj danych wybierz w fiber_lib.py na górze pliku
FIG_SIZE = 25/50/250
num = "_1"/"_2"/"_3"
w zależności od zestawu danych

Pozycję OLT oraz długość obliczeń ustal w pliku wersji którą uruchamiasz, w funkcji main.